$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/fmasm/Katalon Studio/Banking Project_Automation_Test/Include/features/Banking Project/BankingProject.feature");
formatter.feature({
  "name": "Feature file to test on banking project system",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@BankingProject"
    }
  ]
});
formatter.scenario({
  "name": "[Bank Manager] Add customers to the system then delete their information",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@BankingProject"
    },
    {
      "name": "@001"
    }
  ]
});
formatter.step({
  "name": "I login to the system as \u0027Bank Manager\u0027",
  "keyword": "Given "
});
formatter.match({
  "location": "BankingProject.I_login_to_the_system_as_role(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the \u0027Add Customer\u0027 button",
  "keyword": "When "
});
formatter.match({
  "location": "BankingProject.I_click_on_the_button(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I add the following customers by entering \u0027First Name\u0027, \u0027Last Name\u0027, and \u0027Postcode\u0027",
  "rows": [
    {
      "cells": [
        "First Name",
        "Last Name",
        "Postcode"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Kusanagi",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Mina",
        "M098Q585"
      ]
    },
    {
      "cells": [
        "Lola",
        "Rose",
        "A897N450"
      ]
    },
    {
      "cells": [
        "Jackson",
        "Connely",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Noah",
        "Jay",
        "L789C349"
      ]
    }
  ],
  "keyword": "And "
});
formatter.match({
  "location": "BankingProject.I_add_following_customers_to_the_system(String,String,String,DataTable)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I see a confirmation message that the customer has been added",
  "keyword": "Then "
});
formatter.match({
  "location": "BankingProject.I_see_a_confirmation_message_that_the_customer_has_been_added()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the \u0027OK\u0027 button to close the pop-up confirmation message",
  "keyword": "When "
});
formatter.match({
  "location": "BankingProject.I_click_on_the_button_to_close_the_pop_up_confirmation_message(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the \u0027Customers\u0027 button",
  "keyword": "And "
});
formatter.match({
  "location": "BankingProject.I_click_on_the_button(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I verify following customers are inserted in the table based on \u0027First Name\u0027, \u0027Last Name\u0027, and \u0027Postcode\u0027",
  "rows": [
    {
      "cells": [
        "First Name",
        "Last Name",
        "Postcode"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Kusanagi",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Mina",
        "M098Q585"
      ]
    },
    {
      "cells": [
        "Lola",
        "Rose",
        "A897N450"
      ]
    },
    {
      "cells": [
        "Jackson",
        "Connely",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Noah",
        "Jay",
        "L789C349"
      ]
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "BankingProject.verifyCustomersInTable(String,String,String,DataTable)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I delete following customers \u0027First Name\u0027, \u0027Last Name\u0027 and \u0027Postcode\u0027 by clicking \u0027Delete\u0027 button on its row",
  "rows": [
    {
      "cells": [
        "First Name",
        "Last Name",
        "Postcode"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Kusanagi",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Mina",
        "M098Q585"
      ]
    },
    {
      "cells": [
        "Lola",
        "Rose",
        "A897N450"
      ]
    },
    {
      "cells": [
        "Jackson",
        "Connely",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Noah",
        "Jay",
        "L789C349"
      ]
    }
  ],
  "keyword": "When "
});
formatter.match({
  "location": "BankingProject.deleteCustomers(String,String,String,String,DataTable)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I verify following customers are deleted successfully on their \u0027First Name\u0027, \u0027Last Name\u0027, and \u0027Postcode\u0027",
  "rows": [
    {
      "cells": [
        "First Name",
        "Last Name",
        "Postcode"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Kusanagi",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Kyo",
        "Mina",
        "M098Q585"
      ]
    },
    {
      "cells": [
        "Lola",
        "Rose",
        "A897N450"
      ]
    },
    {
      "cells": [
        "Jackson",
        "Connely",
        "L789C349"
      ]
    },
    {
      "cells": [
        "Noah",
        "Jay",
        "L789C349"
      ]
    }
  ],
  "keyword": "Then "
});
formatter.match({
  "location": "BankingProject.I_verify_customer_details_deleted_successfully(String,String,String,DataTable)"
});
formatter.result({
  "status": "passed"
});
});