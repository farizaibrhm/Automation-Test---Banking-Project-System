$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/fmasm/Katalon Studio/Banking Project_Automation_Test/Include/features/Banking Project/BankingProject.feature");
formatter.feature({
  "name": "Feature file to test on banking project system",
  "description": "",
  "keyword": "Feature",
  "tags": [
    {
      "name": "@BankingProject"
    }
  ]
});
formatter.scenario({
  "name": "[Customer] Perform debit and credit transaction",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@BankingProject"
    },
    {
      "name": "@002"
    }
  ]
});
formatter.step({
  "name": "I login to the system as \u0027Customer\u0027",
  "keyword": "Given "
});
formatter.match({
  "location": "BankingProject.I_login_to_the_system_as_role(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select customer name as \u0027Hermoine Granger\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "BankingProject.I_select_customer_name(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I click on the \u0027Login\u0027 button",
  "keyword": "And "
});
formatter.match({
  "location": "BankingProject.I_click_on_the_button(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I select account number \u00271003\u0027 in dropdown",
  "keyword": "And "
});
formatter.match({
  "location": "BankingProject.I_select_number_in_dropdown(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I verify the initial balance is 0",
  "keyword": "Then "
});
formatter.match({
  "location": "BankingProject.I_verify_initial_balance()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I perform debit and credit transaction on \u0027Deposit\u0027 and \u0027Withdrawl\u0027",
  "keyword": "And "
});
formatter.match({
  "location": "BankingProject.I_perform_debit_and_credit_transaction(String,String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "I verify the current balance tallies with balance section on Customer Homepage",
  "keyword": "Then "
});
formatter.match({
  "location": "BankingProject.I_verify_amount_of_current_balance_tallies_with_balance_on_the_homepage()"
});
formatter.result({
  "status": "passed"
});
});