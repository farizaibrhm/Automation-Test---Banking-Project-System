import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When

import io.cucumber.datatable.DataTable


class BankingProject {

	@Given("I login to the system as {string}")
	def I_login_to_the_system_as_role(String role) {
		WebUI.openBrowser('')
		WebUI.delay(5)
		WebUI.navigateToUrl(GlobalVariable.URL)
		if (role == "Bank Manager") {
			WebUI.click(findTestObject('Object Repository/Banking Project/btn_login', ['param': "Bank Manager Login"]))
		} else {
			WebUI.click(findTestObject('Object Repository/Banking Project/btn_login', ['param': "Customer Login"]))
		}
	}

	@When("I click on the {string} button")
	def I_click_on_the_button(String BtnOpt) {
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_optHomePage', ['param': BtnOpt]))
	}

	@When("I add the following customers by entering {string}, {string}, and {string}")
	def I_add_following_customers_to_the_system(String firstNameHeader, String lastNameHeader, String postcodeHeader, DataTable dataTable) {
		List<Map<String, String>> customerData = dataTable.asMaps(String, String)

		customerData.each { customer ->
			WebUI.setText(findTestObject('Object Repository/Banking Project/input_addCustomerPage', ['param': "First Name"]), customer[firstNameHeader])
			WebUI.setText(findTestObject('Object Repository/Banking Project/input_addCustomerPage', ['param': "Last Name"]), customer[lastNameHeader])
			WebUI.setText(findTestObject('Object Repository/Banking Project/input_addCustomerPage', ['param': "Post Code"]), customer[postcodeHeader])

			WebUI.click(findTestObject('Object Repository/Banking Project/btn_AddCustomer'))

			WebUI.delay(2)
		}
	}


	@Then("I see a confirmation message that the customer has been added")
	def I_see_a_confirmation_message_that_the_customer_has_been_added() {
		if (WebUI.verifyAlertPresent(10)) {
			println "Confirmation message displayed: Customer has been added."
		} else {
			println "Confirmation message not displayed."
		}
	}

	@Then("I click on the {string} button to close the pop-up confirmation message")
	def I_click_on_the_button_to_close_the_pop_up_confirmation_message(String btn) {
		WebUI.acceptAlert()
	}

	@Then("I verify following customers are inserted in the table based on {string}, {string}, and {string}")
	def verifyCustomersInTable(String firstNameHeader, String lastNameHeader, String postcodeHeader, DataTable dataTable) {
		List<Map<String, String>> customers = dataTable.asMaps(String, String)

		customers.each { customer ->
			WebUI.scrollToElement(findTestObject('Object Repository/Banking Project/td_columnFirstName',['param': customer[firstNameHeader]]), GlobalVariable.Min_Wait_Time)
			WebUI.scrollToElement(findTestObject('Object Repository/Banking Project/td_columnLastName',['param': customer[lastNameHeader]]), GlobalVariable.Min_Wait_Time)
			WebUI.scrollToElement(findTestObject('Object Repository/Banking Project/td_columnPostcode',['param': customer[postcodeHeader]]), GlobalVariable.Min_Wait_Time)

			WebUI.verifyElementVisible(findTestObject('Object Repository/Banking Project/td_columnFirstName',['param': customer[firstNameHeader]]))
			WebUI.verifyElementVisible(findTestObject('Object Repository/Banking Project/td_columnLastName',['param': customer[lastNameHeader]]))
			WebUI.verifyElementVisible(findTestObject('Object Repository/Banking Project/td_columnPostcode',['param': customer[postcodeHeader]]))
		}
	}

	@When("I delete following customers {string}, {string} and {string} by clicking {string} button on its row")
	def deleteCustomers(String firstNameHeader, String lastNameHeader, String postcodeHeader,String btn, DataTable dataTable) {
		List<Map<String, String>> customers = dataTable.asMaps(String, String)

		customers.each { customer ->
			WebUI.scrollToElement(findTestObject('Object Repository/Banking Project/td_columnFirstName',['param': customer[firstNameHeader]]), GlobalVariable.Min_Wait_Time)
			WebUI.scrollToElement(findTestObject('Object Repository/Banking Project/td_columnLastName',['param': customer[lastNameHeader]]), GlobalVariable.Min_Wait_Time)
			WebUI.scrollToElement(findTestObject('Object Repository/Banking Project/td_columnPostcode',['param': customer[postcodeHeader]]), GlobalVariable.Min_Wait_Time)

			WebUI.click(findTestObject('Object Repository/Banking Project/btn_DeleteSpecificFirstNameLastNamePostcode',['param1': customer[firstNameHeader],'param2': customer[lastNameHeader], 'param3': customer[postcodeHeader], 'param4': btn]))
		}
	}

	@Then("I verify following customers are deleted successfully on their {string}, {string}, and {string}")
	def I_verify_customer_details_deleted_successfully(String firstNameHeader, String lastNameHeader, String postcodeHeader, DataTable dataTable) {
		List<Map<String, String>> customers = dataTable.asMaps(String, String)

		customers.each { customer ->
			WebUI.verifyElementNotPresent(findTestObject('Object Repository/Banking Project/td_columnFirstName',['param': customer[firstNameHeader]]),GlobalVariable.Min_Wait_Time)
			WebUI.verifyElementNotPresent(findTestObject('Object Repository/Banking Project/td_columnLastName',['param': customer[lastNameHeader]]),GlobalVariable.Min_Wait_Time)
			WebUI.verifyElementNotPresent(findTestObject('Object Repository/Banking Project/td_columnPostcode',['param': customer[postcodeHeader]]),GlobalVariable.Min_Wait_Time)
		}
	}

	@When("I select customer name as {string}")
	def I_select_customer_name(String custName) {
		WebUI.click(findTestObject('Object Repository/Banking Project/select_Name'))
		WebUI.selectOptionByLabel(findTestObject('Object Repository/Banking Project/select_Name'), custName, true)
	}

	@When("I select account number {string} in dropdown")
	def I_select_number_in_dropdown(String accNum) {
		WebUI.click(findTestObject('Object Repository/Banking Project/select_accSelect'))
		WebUI.selectOptionByLabel(findTestObject('Object Repository/Banking Project/select_accSelect'), accNum, true)
	}

	@Then("I verify the initial balance is 0")
	def I_verify_initial_balance() {
		WebUI.verifyElementVisible(findTestObject('Object Repository/Banking Project/div_initialBalance0'))
	}

	int expectedBalance = 0

	int amount1 = 50000
	int amount2 = 3000
	int amount3 = 2000
	int amount4 = 5000
	int amount5 = 10000
	int amount6 = 15000
	int amount7 = 1500

	@When("I perform debit and credit transaction on {string} and {string}")
	def I_perform_debit_and_credit_transaction(String depo, String wdrw) {

		String depoBtn = 'Deposit'
		String wdrwBtn = 'Withdraw'
		I_click_on_the_button(depo)
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount1.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':depoBtn]))

		I_click_on_the_button(wdrw)
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount2.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':wdrwBtn]))
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount3.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':wdrwBtn]))

		I_click_on_the_button(depo)
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount4.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':depoBtn]))

		I_click_on_the_button(wdrw)
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount5.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':wdrwBtn]))
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount6.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':wdrwBtn]))

		I_click_on_the_button(depo)
		WebUI.setText(findTestObject('Object Repository/Banking Project/input_amount'), amount7.toString())
		WebUI.click(findTestObject('Object Repository/Banking Project/btn_submit',['param':depoBtn]))

	}

	@Then("I verify the current balance tallies with balance section on Customer Homepage")
	def I_verify_amount_of_current_balance_tallies_with_balance_on_the_homepage() {

		expectedBalance = amount1 - amount2 - amount3 + amount4 - amount5 - amount6 + amount7

		String balanceText = WebUI.getText(findTestObject('Object Repository/Banking Project/div_balance'))
		int actualBalance = balanceText.replaceAll("[^0-9]", "").toInteger()

		if (expectedBalance == actualBalance) {
			println "Balance is correct: $actualBalance"
		} else {
			println "Balance mismatch! Expected: $expectedBalance, Found: $actualBalance"
			KeywordUtil.markFailed("Balance does not match!")
		}
	}

}

