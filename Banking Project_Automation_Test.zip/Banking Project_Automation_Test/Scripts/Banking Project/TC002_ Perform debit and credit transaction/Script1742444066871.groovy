import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW

CucumberKW.runFeatureFileWithTags('Include/features/Banking Project/BankingProject.feature', ((['@002']) as String[]))